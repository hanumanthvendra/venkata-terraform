exports.handler = async (event) => {
    console.log('Received event:', JSON.stringify(event, null, 2));

    const response = {
        statusCode: 200,
        headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
            'Access-Control-Allow-Methods': 'GET,OPTIONS'
        },
        body: JSON.stringify({
            message: 'Hello from Lambda! This is a sample API response.',
            timestamp: new Date().toISOString(),
            environment: process.env.ENVIRONMENT || 'unknown',
            requestId: event.requestContext?.requestId || 'unknown'
        })
    };

    return response;
};
